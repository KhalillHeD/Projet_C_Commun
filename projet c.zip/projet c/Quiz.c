#include "tf_vect.c"
Dict* tf_qvect(char qtxt[1000],int qtf_idf_q[][]){
    int l;
    Dict *qdoc=malloc(sizeof(*qdoc));
    
    l=taille_de_dict(qdoc);
    return qdoc;
}