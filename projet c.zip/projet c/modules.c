#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>

float tf(char term[25], char skills[][25], int longueur_skill);
float idf(char term[25], int nskills, char corpus[nskills][3][25]);

typedef struct Dict Dict;
struct Dict
{
    char mot[25];
    float freq;
    Dict *suivant;
};

Dict *initialisation1(const char array[], float freqe);
void insertion(Dict *liste, const char *nmot, float freqe);
void suppression(Dict **liste);
void affichage(Dict *);
void liberer_liste(Dict *liste);

int main()
{
    char python_vector[3][25] = {"else", "while", "in"};
    char sql_vector[3][25] = {"SELECT", "FROM", "WHERE"};
    char corpus_d[2][3][25];
    memcpy(corpus_d[0], python_vector, sizeof(python_vector));
    memcpy(corpus_d[1], sql_vector, sizeof(sql_vector));
    float x = tf("in", python_vector, 3);
    printf("Term frequency: %.2f\n", x);
    float y = idf("else", 2, corpus_d);
    printf("idf: %.2f\n", y);
    Dict *dict_python = initialisation1(python_vector[0], tf(python_vector[0], python_vector, 3));
    Dict *p_dict_python;
    p_dict_python = &dict_python;
    char *p_mot_2 = &(python_vector[1][0]);
    insertion(p_dict_python, p_mot_2, tf(python_vector[1], python_vector, 3));
    affichage(p_dict_python);
    liberer_liste(p_dict_python);
    return 0;
}
float tf(char term[25], char skill[][25], int longueur_skill)
{
    int k = 0;
    for (int i = 0; i <= longueur_skill - 1; i++)
    {
        if (strcmp(skill[i], term) == 0)
        {
            ++k;
        }
    }

    return (float)k / longueur_skill;
}

float idf(char term[25], int nskills, char corpus[nskills][3][25])
{
    int nbre_de_vecteurs_contenant_terme = 0;
    for (int i = 0; i <= nskills - 1; i++)
    {
        int j = 0;
        bool test = false;
        while ((j < 3) && (test == false))
        {
            if (strcmp(corpus[i][j], term) == 0)
            {
                test = true;
            }
            else
            {
                ++j;
            }
        }
        if (test == true)
        {
            ++nbre_de_vecteurs_contenant_terme;
        }
    }
    if (nbre_de_vecteurs_contenant_terme == 0)
    {
        return 0.0;
    }
    return log(nskills / nbre_de_vecteurs_contenant_terme);
}

Dict *initialisation1(const char array[], float freqe)
{
    Dict *liste = malloc(sizeof(*liste));
    if (liste == NULL)
    {
        exit(EXIT_FAILURE);
    }

    strncpy(liste->mot, array, sizeof(liste->mot) - 1);
    liste->mot[sizeof(liste->mot) - 1] = '\0'; // Assurer la terminaison
    liste->freq = freqe;
    liste->suivant = NULL;

    return liste;
}
void insertion(Dict *liste, const char *nmot, float freqe)
{
    Dict *nouveau = malloc(sizeof(*nouveau));
    if (nouveau == NULL)
    {
        exit(EXIT_FAILURE);
    }

    strncpy(nouveau->mot, nmot, sizeof(nouveau->mot) - 1);
    nouveau->mot[sizeof(nouveau->mot) - 1] = '\0';
    nouveau->freq = freqe;
    nouveau->suivant = liste->suivant;
    liste->suivant = nouveau;
}

void suppression(Dict **liste)
{
    if (*liste == NULL)
    {
        return;
    }

    Dict *aSupprimer = *liste;
    *liste = (*liste)->suivant;
    free(aSupprimer);
}

void affichage(Dict *dictionnaire)
{
    for (Dict *p = dictionnaire; p != NULL; ++p)
    {
        printf("{ %s ,%f } ", p->mot, p->freq);
    }
}

void liberer_liste(Dict *liste)
{
    while (liste != NULL)
    {
        Dict *temp = liste;
        liste = liste->suivant;
        free(temp);
    }
}
